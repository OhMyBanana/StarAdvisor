package com.example.googlemapsdemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;

import io.radar.sdk.Radar;

public class MainActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener, GoogleMap.OnMarkerDragListener, GoogleMap.OnInfoWindowClickListener {

    GoogleMap map;
    Location locFromAPI;
    FirebaseDatabase database;
    DatabaseReference databaseReference;

    LocationManager locationManager;
    double latitude = 0;
    double longitude = 0;
    Location currentPos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        LocationListener locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                latitude = location.getLatitude();
                longitude = location.getLongitude();
                currentPos = new Location("CurrentLoc");
                currentPos.setLatitude(latitude);
                currentPos.setLongitude(longitude);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        };
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    Activity#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for Activity#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);

        Radar.initialize(this,     "prj_test_pk_b9ba06706efb0fe2257be1abbda4d3f949051006");
        if(ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            try {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 101);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        Radar.getLocation(new Radar.RadarLocationCallback() {
            @Override
            public void onComplete(@NotNull Radar.RadarStatus radarStatus, @Nullable Location location, boolean b) {
                try {
                    locFromAPI = location;
                    Log.d("Radar Test:", locFromAPI.toString());

                } catch (Exception e) {
                    e.printStackTrace();
                    locFromAPI = currentPos;
                    Log.d("Android Test:", locFromAPI.toString());
                }
            }
        });

        database=FirebaseDatabase.getInstance("https://staradvisor-75215.firebaseio.com/");
        databaseReference=database.getReferenceFromUrl("https://staradvisor-75215.firebaseio.com/AddNew");

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync( this);
    }

    private void locationsFromDatabase(){
        databaseReference=database.getReferenceFromUrl("https://staradvisor-75215.firebaseio.com/Addresses");
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    ArrayList<ObservationSite> locations=new ArrayList<>();
                    ObservationSite temp=new ObservationSite();
                    for (DataSnapshot snaphot : dataSnapshot.getChildren()){
                        temp.address=snaphot.getKey();
                        temp.latitude=Double.valueOf(snaphot.child("Latitude").getValue().toString());
                        temp.longitude=Double.valueOf(snaphot.child("Longitude").getValue().toString());
                        temp.clouds=Double.valueOf(snaphot.child("clouds").getValue().toString());
                        temp.dt=snaphot.child("dt").getValue().toString();
                        temp.temp=Double.valueOf(snaphot.child("temp").getValue().toString());
                        locations.add(temp);


                        LatLng Spot1 = new LatLng(temp.latitude, temp.longitude);
                        map.addMarker(new MarkerOptions().position(Spot1).title(temp.address).snippet("Cloud Coverage: " + temp.clouds +
                                "%\n Temperature: " + temp.temp + "\n Date of Last Forecast: " + temp.dt));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }

            });

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        googleMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.message));

        LatLng You = new LatLng(locFromAPI.getLatitude(), locFromAPI.getLongitude());
        map.addMarker(new MarkerOptions().position(You).title(
                "Add Location To Database").draggable(true).icon(
                        BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
        locationsFromDatabase();
//
//        LatLng Spot1 = new LatLng(40.93837, -73.962405);
//        map.addMarker(new MarkerOptions().position(Spot1).title("Spot One").snippet("stuff"));
//
//        LatLng Spot2 = new LatLng(40.908611, -73.910111);
//        map.addMarker(new MarkerOptions().position(Spot2).title("Spot Two"));
//
//        LatLng Spot3 = new LatLng(40.937229, -73.962500);
//        map.addMarker(new MarkerOptions().position(Spot3).title("Spot Three"));
//
//        LatLng Spot4 = new LatLng(40.918009, -73.921099);
//        map.addMarker(new MarkerOptions().position(Spot4).title("Spot Four"));
//
//        LatLng Spot5 = new LatLng(40.944478, -73.961887);
//        map.addMarker(new MarkerOptions().position(Spot5).title("Spot Five"));
//
//        LatLng Spot6 = new LatLng(40.915122, -73.932931);
//        map.addMarker(new MarkerOptions().position(Spot6).title("Spot Six"));

        map.moveCamera(CameraUpdateFactory.newLatLngZoom(You, 12.0f));


        map.setOnInfoWindowClickListener(this);
    }

    @Override
    public void onInfoWindowClick(Marker marker) {
        //TEST ADD TO DATABASE
        if (marker.isDraggable()) {
            databaseReference = databaseReference.push();
            databaseReference.setValue("TEST MESSAGE");
            databaseReference = databaseReference.child("Latitude");
            databaseReference.setValue(marker.getPosition().latitude);
            databaseReference = databaseReference.getParent();
            databaseReference = databaseReference.child("Longitude");
            databaseReference.setValue(marker.getPosition().longitude);
            databaseReference = database.getReferenceFromUrl("https://staradvisor-75215.firebaseio.com/AddNew");
        }
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        return false;
    }

    @Override
    public void onMarkerDragStart(Marker marker) {

    }

    @Override
    public void onMarkerDrag(Marker marker) {

    }

    @Override
    public void onMarkerDragEnd(Marker marker) {

    }

    public class ObservationSite{
        String address;
        double latitude;
        double longitude;
        double clouds;
        String dt;
        double temp;

        ObservationSite(){
            String address="";
            double latitude=0;
            double longitude=0;
            double clouds=0;
            String dt="";
            double temp=0;
        }

        ObservationSite(String address,double latitude,double longitude, double clouds, String dt, double temp){
            this.address=address;
            this.latitude=latitude;
            this.longitude=longitude;
            this.clouds=clouds;
            this.dt=dt;
            this.temp=temp;
        }

        @Override
        public String toString() {
            return ("ObservationSite{" +
                    "address='" + address + "'" +
                    ", latitude=" + latitude +
                    ", longitude=" + longitude +
                    ", clouds=" + clouds +
                    ", dt='" + dt + "'" +
                    ", temp=" + temp +
                    '}');
        }
    }
}
